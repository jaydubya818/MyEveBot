# MyEve Relay adapter

Integration base: `/Users/jaywest/Myeve`, `codex/openbot`,
`74fee5b1fdc8ec7c705a9087d9bdf58992b8f27c`, clean before isolation.
Integration worktree: `myeve-relay-federation`, branch
`feat/relay-federation-adapter`. Relay remains pinned and unchanged at
`614c638d6fc4099db8064540326f5de4438e93a1`.

## Current architecture audit

MyEve is a Next.js 16 / React 19 application using Eve 0.27.7. Authenticated
owners are resolved by `web-auth.ts`; persisted Agents belong to owners and
have explicit capabilities, risk ceilings, and execution limits. Knowledge is
canonical in PostgreSQL `knowledge_records`, sources, provenance links, and
relationships. Memory uses owner/Agent/Goal scopes and an optional Supermemory
backend. Goals, Workspace, conversations, and task runs are separate local
domains. Control Center reads `task_runs`, approvals, milestones, and computer
state. ActionGateway enforces local capability policy and exact-action approvals.
Execution occurrences and action ledgers provide durable fencing and recovery.

There was no Relay federation client. Existing references to Relay were role
instructions and unrelated VNC relay code. No production environment files are
copied into this worktree, and no shared database is migrated.

## Adapter boundaries

Owner-authorized publication code may select canonical Knowledge. It materializes
an explicit, immutable publication projection. External query code receives only
a publication-reader capability; it does not import canonical Knowledge, Memory,
Goals, conversations, Workspace, or the general Agent tool runtime. Everything is
PRIVATE unless the authenticated owner confirms an exact publication preview.

Relay carries addresses, grants, references, signed delivery, lifecycle, and audit
evidence. Incoming work must additionally pass MyEve local policy. Local Runs stay
in MyEve and correlate to, rather than being replaced by, Relay request IDs.
External knowledge remains sourced external context, without automatic promotion.

Relay's current remote API does not expose audit export retrieval. The existing
signed audit-export format can be imported and independently verified using a
pinned Relay public key. MyEve local delivery activity is distinct from imported
Relay-signed disclosure receipts. This avoids an unqualified protocol extension.
Relay owner-session operations remain distinct from Agent bearer authentication.

## Qualification state

- Federation protocol: PASSED_LIVE, disposable platforms (previous mission).
- MyEve adapter: INCOMPLETE, implementation in progress.
- Production multi-platform: NOT_RUN.
- Independent security review: NOT_RUN.

Baseline application Vitest: 402 passed in 63 files. Root Node test command:
125 passed, one file startup failure in `web-auth.test.mjs`, before adapter code.
