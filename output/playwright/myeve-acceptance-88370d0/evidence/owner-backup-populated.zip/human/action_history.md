# Action history

Action Gateway decisions, safe targets, attempts, and receipt timeline without executable authority

Completeness: metadata only
Portability: non restorable

> Action requests and receipts are owner-readable audit evidence only. Exact parameters, binding hashes, provider payloads, recovery tokens, and active authorization are excluded.

## requests

No records.

## receipts

No records.
