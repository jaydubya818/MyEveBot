# Routines & schedules

Owner-scoped Routine definitions, versions, occurrences, attempts, and delivery history

Completeness: complete
Portability: partially restorable

> Routine definitions and version history may be portable, but restore must force disabled status and fresh owner review. Occurrences, attempts, claims, approvals, and delivery authority are historical only.

## reminders

No records.

## routines

No records.

## versions

No records.

## occurrences

No records.

## attempts

No records.

## deliveries

No records.
