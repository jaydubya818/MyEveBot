# Files & artifacts

Owner file and artifact metadata with explicit portability classification

Completeness: partial
Portability: reference only

> Binary file contents are not embedded in v1. Metadata and checksums do not by themselves constitute a file backup.

## chat Files

No records.

## task Artifacts

No records.

## computer Artifacts

No records.
