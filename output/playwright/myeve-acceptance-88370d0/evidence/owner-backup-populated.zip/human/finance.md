# Finance

Owner-entered receipt and purchase records

Completeness: complete
Portability: fully restorable

> This is legacy single-owner deployment state; the receipts table does not yet provide row-level owner isolation.

## receipts

No records.
