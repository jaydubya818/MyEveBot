# Connected apps

Safe connected-account metadata without authorization credentials

Completeness: unavailable
Portability: unavailable

> Connected-account metadata was unavailable when this backup was created.

## connected Accounts

No records.
