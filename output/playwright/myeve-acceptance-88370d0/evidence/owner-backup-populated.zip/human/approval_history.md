# Approval history

Exact-action approval bindings, risk, expected effects, status, expiry, and decisions

Completeness: complete
Portability: non restorable

> Approval bindings and decisions are audit history. A restore must never reactivate pending or approved execution authority.

## approvals

### approvals 1

- **id:** approval_225b25c4-7731-4b91-86e5-3f159161c18d
- **task_id:** task_558742fc-b381-40bb-ac05-353aee15975c
- **goal_id:** goal_b96e7077-00db-43dd-913c-372f69f9301e
- **goal_task_id:** —
- **agent_id:** agent_50e31774-3453-4697-9c92-6c4289f4a44c
- **role_id:** —
- **capability_id:** web.read
- **provider:** —
- **action:** Read the synthetic Atlas acceptance notes
- **action_class:** read
- **binding_hash:** f1aeeb5670a04f790bdab946f8f3626e151dec9f6f728e36ae9506878e6ddad8
- **risk:** low
- **effects:** `[   "Read one synthetic local evidence fixture. No external action will execute." ]`
- **estimated_cost_usd:** —
- **expires_at:** `"2026-09-20T21:14:51.933Z"`
- **status:** approved
- **decision:** approved
- **decision_reason:** —
- **requested_by:** agent_50e31774-3453-4697-9c92-6c4289f4a44c
- **decided_by:** acceptance-sarah
- **requested_at:** `"2026-09-20T20:14:51.933Z"`
- **decided_at:** `"2026-09-20T20:19:31.010Z"`
- **authority:** historical_only
- **restorableAuthority:** false

### approvals 2

- **id:** approval_4a47dc26-898e-41ec-8b10-10b29b3eb7d0
- **task_id:** task_e9647246-ef5f-47d5-82cd-44f5403cd644
- **goal_id:** goal_b96e7077-00db-43dd-913c-372f69f9301e
- **goal_task_id:** —
- **agent_id:** agent_50e31774-3453-4697-9c92-6c4289f4a44c
- **role_id:** —
- **capability_id:** web.read
- **provider:** —
- **action:** Read the synthetic Atlas acceptance notes
- **action_class:** read
- **binding_hash:** 7a551172ab0f643aa4082dfee65081944e64032bfd3a27bb5e0e17508ff20dde
- **risk:** low
- **effects:** `[   "Read one synthetic local evidence fixture. No external action will execute." ]`
- **estimated_cost_usd:** —
- **expires_at:** `"2026-09-20T21:14:51.936Z"`
- **status:** denied
- **decision:** denied
- **decision_reason:** —
- **requested_by:** agent_50e31774-3453-4697-9c92-6c4289f4a44c
- **decided_by:** acceptance-sarah
- **requested_at:** `"2026-09-20T20:14:51.936Z"`
- **decided_at:** `"2026-09-20T20:19:10.619Z"`
- **authority:** historical_only
- **restorableAuthority:** false

### approvals 3

- **id:** approval_18b2db4c-a02a-4c5d-908b-1a46f0914a64
- **task_id:** task_56e25857-9f8f-4554-a296-e89f76cc3bef
- **goal_id:** goal_b96e7077-00db-43dd-913c-372f69f9301e
- **goal_task_id:** —
- **agent_id:** agent_50e31774-3453-4697-9c92-6c4289f4a44c
- **role_id:** —
- **capability_id:** web.read
- **provider:** —
- **action:** Read the synthetic Atlas acceptance notes
- **action_class:** read
- **binding_hash:** 59e2ed06dc6aadd344e14e6fc4ee8f4df940805091fa2da7ee0811fa2a4e4325
- **risk:** low
- **effects:** `[   "Read one synthetic local evidence fixture. No external action will execute." ]`
- **estimated_cost_usd:** —
- **expires_at:** `"2026-09-20T21:14:51.939Z"`
- **status:** approved
- **decision:** approved
- **decision_reason:** —
- **requested_by:** agent_50e31774-3453-4697-9c92-6c4289f4a44c
- **decided_by:** acceptance-sarah
- **requested_at:** `"2026-09-20T20:14:51.939Z"`
- **decided_at:** `"2026-09-20T20:18:22.626Z"`
- **authority:** historical_only
- **restorableAuthority:** false
