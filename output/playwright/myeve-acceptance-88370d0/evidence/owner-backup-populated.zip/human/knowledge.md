# Knowledge

Knowledge records, sources, provenance, and relationships

Completeness: complete
Portability: fully restorable

## sources

### sources 1

- **id:** source_008f5a55-3786-464f-ad82-d21195a54269
- **source_type:** manual
- **provider:** —
- **external_id:** —
- **reference_uri:** urn:myeve:acceptance:atlas-synthetic-notes
- **author:** Sarah
- **captured_at:** `"2026-09-20T20:03:27.242Z"`
- **content_hash:** —
- **snapshot_ref:** —
- **created_at:** `"2026-09-20T20:03:27.242Z"`

## records

### records 1

- **id:** knowledge_5c28dd80-3ca7-4fbf-ae90-97bba24b21da
- **kind:** fact
- **title:** —
- **statement:** Project Atlas pilot launch is October 1, 2026.
- **confidence:** 1.000
- **status:** superseded
- **occurrence_count:** —
- **first_seen_at:** —
- **last_confirmed_at:** —
- **first_observed_at:** —
- **last_observed_at:** —
- **test_description:** —
- **decision_trigger:** —
- **rationale:** —
- **alternatives:** `[]`
- **decided_at:** —
- **reopen_condition:** —
- **subject:** —
- **due_at:** —
- **fulfilled_at:** —
- **preference_key:** —
- **preference_value:** —
- **preference_scope:** —
- **preference_source_type:** —
- **preference_source_id:** —
- **active:** —
- **review_at:** —
- **expires_at:** —
- **generated_at:** —
- **created_by_type:** owner
- **created_by_id:** —
- **goal_id:** goal_b96e7077-00db-43dd-913c-372f69f9301e
- **project_ref:** Project Atlas
- **supersedes_id:** —
- **created_at:** `"2026-09-20T20:03:28.194Z"`
- **updated_at:** `"2026-09-20T20:07:27.193Z"`

### records 2

- **id:** knowledge_794cbc86-2db4-418d-99f7-86bdeab55233
- **kind:** hypothesis
- **title:** —
- **statement:** Reducing Project Atlas account setup steps will improve onboarding completion.
- **confidence:** 0.500
- **status:** open
- **occurrence_count:** —
- **first_seen_at:** —
- **last_confirmed_at:** —
- **first_observed_at:** —
- **last_observed_at:** —
- **test_description:** Compare completion before and after removing two steps.
- **decision_trigger:** —
- **rationale:** —
- **alternatives:** `[]`
- **decided_at:** —
- **reopen_condition:** —
- **subject:** —
- **due_at:** —
- **fulfilled_at:** —
- **preference_key:** —
- **preference_value:** —
- **preference_scope:** —
- **preference_source_type:** —
- **preference_source_id:** —
- **active:** —
- **review_at:** —
- **expires_at:** —
- **generated_at:** —
- **created_by_type:** owner
- **created_by_id:** —
- **goal_id:** goal_b96e7077-00db-43dd-913c-372f69f9301e
- **project_ref:** Project Atlas
- **supersedes_id:** —
- **created_at:** `"2026-09-20T20:03:28.206Z"`
- **updated_at:** `"2026-09-20T20:03:28.206Z"`

### records 3

- **id:** knowledge_e63f319f-00b8-4663-85f9-ec6f32377550
- **kind:** commitment
- **title:** —
- **statement:** Review Project Atlas pilot results Friday.
- **confidence:** 1.000
- **status:** open
- **occurrence_count:** —
- **first_seen_at:** —
- **last_confirmed_at:** —
- **first_observed_at:** —
- **last_observed_at:** —
- **test_description:** —
- **decision_trigger:** —
- **rationale:** —
- **alternatives:** `[]`
- **decided_at:** —
- **reopen_condition:** —
- **subject:** Sarah
- **due_at:** `"2026-09-25T23:00:00.000Z"`
- **fulfilled_at:** —
- **preference_key:** —
- **preference_value:** —
- **preference_scope:** —
- **preference_source_type:** —
- **preference_source_id:** —
- **active:** —
- **review_at:** —
- **expires_at:** —
- **generated_at:** —
- **created_by_type:** owner
- **created_by_id:** —
- **goal_id:** goal_b96e7077-00db-43dd-913c-372f69f9301e
- **project_ref:** Project Atlas
- **supersedes_id:** —
- **created_at:** `"2026-09-20T20:03:28.212Z"`
- **updated_at:** `"2026-09-20T20:03:28.212Z"`

### Project Atlas phased launch

- **id:** knowledge_dd5729ca-a57e-405e-9f89-df668748aed7
- **kind:** decision
- **title:** Project Atlas phased launch
- **statement:** Use a phased launch for Project Atlas.
- **confidence:** 1.000
- **status:** active
- **occurrence_count:** —
- **first_seen_at:** —
- **last_confirmed_at:** —
- **first_observed_at:** —
- **last_observed_at:** —
- **test_description:** —
- **decision_trigger:** —
- **rationale:** Reduce rollout risk.
- **alternatives:** `[]`
- **decided_at:** `"2026-09-20T20:04:18.218Z"`
- **reopen_condition:** Pilot adoption is below target.
- **subject:** —
- **due_at:** —
- **fulfilled_at:** —
- **preference_key:** —
- **preference_value:** —
- **preference_scope:** —
- **preference_source_type:** —
- **preference_source_id:** —
- **active:** —
- **review_at:** —
- **expires_at:** —
- **generated_at:** —
- **created_by_type:** owner
- **created_by_id:** —
- **goal_id:** goal_b96e7077-00db-43dd-913c-372f69f9301e
- **project_ref:** —
- **supersedes_id:** —
- **created_at:** `"2026-09-20T20:04:18.225Z"`
- **updated_at:** `"2026-09-20T20:04:18.225Z"`

### records 5

- **id:** knowledge_4b8e6429-9cc9-4b0e-aa5b-b05a1593f6a6
- **kind:** observation
- **title:** —
- **statement:** Project Atlas users abandon onboarding most often during account setup.
- **confidence:** 0.700
- **status:** active
- **occurrence_count:** 3
- **first_seen_at:** —
- **last_confirmed_at:** —
- **first_observed_at:** `"2026-09-20T20:04:18.218Z"`
- **last_observed_at:** `"2026-09-20T20:04:18.218Z"`
- **test_description:** —
- **decision_trigger:** —
- **rationale:** —
- **alternatives:** `[]`
- **decided_at:** —
- **reopen_condition:** —
- **subject:** —
- **due_at:** —
- **fulfilled_at:** —
- **preference_key:** —
- **preference_value:** —
- **preference_scope:** —
- **preference_source_type:** —
- **preference_source_id:** —
- **active:** —
- **review_at:** —
- **expires_at:** —
- **generated_at:** —
- **created_by_type:** owner
- **created_by_id:** —
- **goal_id:** goal_b96e7077-00db-43dd-913c-372f69f9301e
- **project_ref:** —
- **supersedes_id:** —
- **created_at:** `"2026-09-20T20:04:18.237Z"`
- **updated_at:** `"2026-09-20T20:04:18.237Z"`

### records 6

- **id:** knowledge_d3a773ac-570f-4943-8c90-6be893e8c8c3
- **kind:** fact
- **title:** —
- **statement:** Project Atlas pilot launch moved to October 15, 2026.
- **confidence:** 1.000
- **status:** active
- **occurrence_count:** —
- **first_seen_at:** —
- **last_confirmed_at:** `"2026-09-20T20:07:27.191Z"`
- **first_observed_at:** —
- **last_observed_at:** —
- **test_description:** —
- **decision_trigger:** —
- **rationale:** —
- **alternatives:** `[]`
- **decided_at:** —
- **reopen_condition:** —
- **subject:** —
- **due_at:** —
- **fulfilled_at:** —
- **preference_key:** —
- **preference_value:** —
- **preference_scope:** —
- **preference_source_type:** —
- **preference_source_id:** —
- **active:** —
- **review_at:** —
- **expires_at:** —
- **generated_at:** —
- **created_by_type:** owner
- **created_by_id:** —
- **goal_id:** goal_b96e7077-00db-43dd-913c-372f69f9301e
- **project_ref:** Project Atlas
- **supersedes_id:** knowledge_5c28dd80-3ca7-4fbf-ae90-97bba24b21da
- **created_at:** `"2026-09-20T20:07:27.193Z"`
- **updated_at:** `"2026-09-20T20:07:27.193Z"`

## provenance

### provenance 1

- **id:** provenance_5f456d85-d3d9-4df9-ac74-4aab1872801a
- **knowledge_id:** knowledge_5c28dd80-3ca7-4fbf-ae90-97bba24b21da
- **source_id:** source_008f5a55-3786-464f-ad82-d21195a54269
- **relation:** supports
- **confidence:** 1.000
- **created_at:** `"2026-09-20T20:03:28.194Z"`

### provenance 2

- **id:** provenance_c5eebef6-dd2a-4aa6-b7e4-9c5cc4a1012d
- **knowledge_id:** knowledge_794cbc86-2db4-418d-99f7-86bdeab55233
- **source_id:** source_008f5a55-3786-464f-ad82-d21195a54269
- **relation:** supports
- **confidence:** 1.000
- **created_at:** `"2026-09-20T20:03:28.206Z"`

### provenance 3

- **id:** provenance_97d8b5b7-dd69-46ad-ab59-739d70d3e37b
- **knowledge_id:** knowledge_e63f319f-00b8-4663-85f9-ec6f32377550
- **source_id:** source_008f5a55-3786-464f-ad82-d21195a54269
- **relation:** supports
- **confidence:** 1.000
- **created_at:** `"2026-09-20T20:03:28.212Z"`

### provenance 4

- **id:** provenance_fa72c491-0312-4786-ab06-703cd37dbe14
- **knowledge_id:** knowledge_dd5729ca-a57e-405e-9f89-df668748aed7
- **source_id:** source_008f5a55-3786-464f-ad82-d21195a54269
- **relation:** supports
- **confidence:** 1.000
- **created_at:** `"2026-09-20T20:04:18.225Z"`

### provenance 5

- **id:** provenance_1c789da9-b17b-4b19-907f-6945649d1274
- **knowledge_id:** knowledge_4b8e6429-9cc9-4b0e-aa5b-b05a1593f6a6
- **source_id:** source_008f5a55-3786-464f-ad82-d21195a54269
- **relation:** supports
- **confidence:** 1.000
- **created_at:** `"2026-09-20T20:04:18.237Z"`

### provenance 6

- **id:** provenance_c3b89cd0-d022-4ed2-b776-ae636e9cadf8
- **knowledge_id:** knowledge_d3a773ac-570f-4943-8c90-6be893e8c8c3
- **source_id:** source_008f5a55-3786-464f-ad82-d21195a54269
- **relation:** supports
- **confidence:** 1.000
- **created_at:** `"2026-09-20T20:07:27.193Z"`

## relationships

No records.
