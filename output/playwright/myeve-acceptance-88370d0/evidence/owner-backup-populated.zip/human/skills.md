# Skills

Private Skills, assignments, usage, and evaluation metadata

Completeness: partial
Portability: partially restorable

> Private Skill contents were unavailable; assignment and evaluation metadata is included.

## assignments

No records.

## usage

No records.

## eval Runs

No records.

## eval Results

No records.

## private Skills

No records.
