# Computer history

Computer and browser session, action, and control history without live provider authority

Completeness: metadata only
Portability: non restorable

> Computer and browser sessions, control state, and actions are audit history only. Provider sessions, checkpoints, credentials, and live control authority are excluded.

## sessions

No records.

## browser Sessions

No records.

## control Leases

No records.

## control Receipts

No records.

## actions

No records.
