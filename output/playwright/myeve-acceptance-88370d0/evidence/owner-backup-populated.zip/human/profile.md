# Profile & settings

Owner-facing review and delivery settings

Completeness: complete
Portability: fully restorable

## review Preferences

No records.
