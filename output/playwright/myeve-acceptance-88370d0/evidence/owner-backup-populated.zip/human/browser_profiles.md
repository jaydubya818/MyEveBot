# Browser profiles

Persistent Browser Profile and Agent grant metadata without provider authentication state

Completeness: metadata only
Portability: restorable with reconnection

> Provider authentication state is excluded. A future restore must reconnect profiles and revalidate every Agent grant.

## profiles

### profiles 1

- **id:** browser_profile_e1688235-34aa-44b8-b0a4-b6d75ebd83a1
- **agent_id:** agent_66a1e235-c274-4052-a0aa-db757e9b3e6b
- **provider:** orgo
- **status:** ready
- **generation:** 1
- **last_used_at:** —
- **last_owner_takeover_at:** —
- **last_authenticated_at:** —
- **revoked_at:** —
- **created_at:** `"2026-09-20T20:00:50.955Z"`
- **updated_at:** `"2026-09-20T20:00:50.955Z"`
- **authentication:** requires_reconnection

### profiles 2

- **id:** browser_profile_06f70d16-9718-47f1-a334-786ab5fa315b
- **agent_id:** agent_50e31774-3453-4697-9c92-6c4289f4a44c
- **provider:** orgo
- **status:** ready
- **generation:** 1
- **last_used_at:** —
- **last_owner_takeover_at:** —
- **last_authenticated_at:** —
- **revoked_at:** —
- **created_at:** `"2026-09-20T20:00:51.018Z"`
- **updated_at:** `"2026-09-20T20:00:51.018Z"`
- **authentication:** requires_reconnection

### profiles 3

- **id:** browser_profile_29409b55-236a-432f-a8b1-4d1108497555
- **agent_id:** agent_edd02220-a18a-4106-ae13-98e9cdbba2a7
- **provider:** orgo
- **status:** ready
- **generation:** 1
- **last_used_at:** —
- **last_owner_takeover_at:** —
- **last_authenticated_at:** —
- **revoked_at:** —
- **created_at:** `"2026-09-20T20:00:51.018Z"`
- **updated_at:** `"2026-09-20T20:00:51.018Z"`
- **authentication:** requires_reconnection

## grants

### grants 1

- **id:** browser_grant_51912074-c4f6-4604-93ff-ec3c6b597745
- **profile_id:** browser_profile_e1688235-34aa-44b8-b0a4-b6d75ebd83a1
- **agent_id:** agent_50e31774-3453-4697-9c92-6c4289f4a44c
- **granted_at:** `"2026-09-20T20:33:07.147Z"`
- **revoked_at:** `"2026-09-20T20:33:07.752Z"`
- **authority:** requires_target_capability_reconciliation
