# Agents

Agent definitions, limits, assigned capabilities, and lifecycle history

Completeness: complete
Portability: fully restorable

## agents

### Ava

- **id:** agent_66a1e235-c274-4052-a0aa-db757e9b3e6b
- **name:** Ava
- **slug:** ava
- **label:** —
- **role:** Primary personal agent
- **description:** Helps the owner interpret goals, plan work, focus, and review progress.
- **instructions:** You are the owner's primary personal agent.
- **status:** active
- **is_primary:** true
- **preferred_model:** anthropic/claude-sonnet-5
- **reasoning_preference:** default
- **avatar_config:** `{}`
- **risk_ceiling:** high
- **notification_policy:** activity
- **max_steps:** 20
- **max_runtime_seconds:** 900
- **max_estimated_cost_usd:** 2.0000
- **max_retries:** 1
- **created_by_type:** system
- **created_by_id:** —
- **created_at:** `"2026-09-20T19:45:32.629Z"`
- **updated_at:** `"2026-09-20T19:45:32.629Z"`
- **archived_at:** —

### Analyst

- **id:** agent_50e31774-3453-4697-9c92-6c4289f4a44c
- **name:** Analyst
- **slug:** analyst
- **label:** —
- **role:** Pilot evidence analyst
- **description:** Reviews Project Atlas evidence without external actions.
- **instructions:** You are Analyst. Review supplied Project Atlas evidence. State uncertainties. Do not contact anyone, browse external services, or mutate business records without explicit owner approval.
- **status:** active
- **is_primary:** false
- **preferred_model:** openai/gpt-5.2
- **reasoning_preference:** low
- **avatar_config:** `{}`
- **risk_ceiling:** low
- **notification_policy:** activity
- **max_steps:** 5
- **max_runtime_seconds:** 120
- **max_estimated_cost_usd:** 0.2500
- **max_retries:** 0
- **created_by_type:** owner
- **created_by_id:** acceptance-sarah
- **created_at:** `"2026-09-20T19:58:29.662Z"`
- **updated_at:** `"2026-09-20T20:22:39.613Z"`
- **archived_at:** —

### Analyst Copy

- **id:** agent_553b0c31-1c69-4eb6-bb02-752473013119
- **name:** Analyst Copy
- **slug:** analyst-copy
- **label:** —
- **role:** Pilot evidence analyst
- **description:** Reviews Project Atlas evidence without external actions.
- **instructions:** You are Analyst. Review supplied Project Atlas evidence. State uncertainties. Do not contact anyone, browse external services, or mutate business records without explicit owner approval.
- **status:** archived
- **is_primary:** false
- **preferred_model:** openai/gpt-5.2
- **reasoning_preference:** low
- **avatar_config:** `{}`
- **risk_ceiling:** low
- **notification_policy:** activity
- **max_steps:** 5
- **max_runtime_seconds:** 120
- **max_estimated_cost_usd:** 0.2500
- **max_retries:** 0
- **created_by_type:** owner
- **created_by_id:** acceptance-sarah
- **created_at:** `"2026-09-20T19:58:59.889Z"`
- **updated_at:** `"2026-09-20T19:59:00.424Z"`
- **archived_at:** `"2026-09-20T19:59:00.424Z"`

### Founder / Chief of Staff

- **id:** agent_edd02220-a18a-4106-ae13-98e9cdbba2a7
- **name:** Founder / Chief of Staff
- **slug:** founder-chief-of-staff
- **label:** —
- **role:** Founder / Chief of Staff
- **description:** Coordinates business Goals across operating domains, identifies the current constraint, and prepares owner decisions and reviews.
- **instructions:** Coordinate the owner's business Goal through Business State, Constraint, Domain, Role or Workflow, Work, Evidence, Owner Decision, Outcome, Metrics, and Learning. Diagnose the narrowest current constraint before proposing work. Never fabricate missing metrics. Keep external communication, publishing, spending, price changes, contracts, hiring decisions, payments, deployments, and live-system changes behind explicit Relay approval.
- **status:** active
- **is_primary:** false
- **preferred_model:** —
- **reasoning_preference:** high
- **avatar_config:** `{}`
- **risk_ceiling:** medium
- **notification_policy:** activity
- **max_steps:** 20
- **max_runtime_seconds:** 900
- **max_estimated_cost_usd:** 2.0000
- **max_retries:** 1
- **created_by_type:** owner
- **created_by_id:** acceptance-sarah
- **created_at:** `"2026-09-20T20:00:18.432Z"`
- **updated_at:** `"2026-09-20T20:00:18.432Z"`
- **archived_at:** —

## capabilities

### capabilities 1

- **agent_id:** agent_edd02220-a18a-4106-ae13-98e9cdbba2a7
- **capability_id:** files.read
- **enabled:** true
- **assigned_by_type:** owner
- **assigned_by_id:** acceptance-sarah
- **created_at:** `"2026-09-20T20:00:18.432Z"`
- **updated_at:** `"2026-09-20T20:00:18.432Z"`

### capabilities 2

- **agent_id:** agent_edd02220-a18a-4106-ae13-98e9cdbba2a7
- **capability_id:** files.write
- **enabled:** true
- **assigned_by_type:** owner
- **assigned_by_id:** acceptance-sarah
- **created_at:** `"2026-09-20T20:00:18.432Z"`
- **updated_at:** `"2026-09-20T20:00:18.432Z"`

### capabilities 3

- **agent_id:** agent_edd02220-a18a-4106-ae13-98e9cdbba2a7
- **capability_id:** goals.operating-system
- **enabled:** true
- **assigned_by_type:** owner
- **assigned_by_id:** acceptance-sarah
- **created_at:** `"2026-09-20T20:00:18.432Z"`
- **updated_at:** `"2026-09-20T20:00:18.432Z"`

### capabilities 4

- **agent_id:** agent_edd02220-a18a-4106-ae13-98e9cdbba2a7
- **capability_id:** web.read
- **enabled:** true
- **assigned_by_type:** owner
- **assigned_by_id:** acceptance-sarah
- **created_at:** `"2026-09-20T20:00:18.432Z"`
- **updated_at:** `"2026-09-20T20:00:18.432Z"`

### capabilities 5

- **agent_id:** agent_edd02220-a18a-4106-ae13-98e9cdbba2a7
- **capability_id:** web.search
- **enabled:** true
- **assigned_by_type:** owner
- **assigned_by_id:** acceptance-sarah
- **created_at:** `"2026-09-20T20:00:18.432Z"`
- **updated_at:** `"2026-09-20T20:00:18.432Z"`

## audit History

### auditHistory 1

- **id:** agent_event_1dded9b5-943e-477b-8adf-9a2f9f50d018
- **agent_id:** agent_66a1e235-c274-4052-a0aa-db757e9b3e6b
- **event_type:** created
- **actor_type:** system
- **actor_id:** —
- **summary:** Ava initialized as the primary Agent.
- **changes:** `{}`
- **created_at:** `"2026-09-20T19:45:32.635Z"`

### auditHistory 2

- **id:** agent_event_c0a3ba47-243b-4b74-9ac8-9fdf6cb73de7
- **agent_id:** agent_50e31774-3453-4697-9c92-6c4289f4a44c
- **event_type:** created
- **actor_type:** owner
- **actor_id:** acceptance-sarah
- **summary:** Analyst Agent created.
- **changes:** `{   "capabilityIds": [] }`
- **created_at:** `"2026-09-20T19:58:29.662Z"`

### auditHistory 3

- **id:** agent_event_bf1d4c04-4545-4d13-be39-bef71a49eddc
- **agent_id:** agent_50e31774-3453-4697-9c92-6c4289f4a44c
- **event_type:** paused
- **actor_type:** owner
- **actor_id:** acceptance-sarah
- **summary:** Analyst paused.
- **changes:** `{}`
- **created_at:** `"2026-09-20T19:58:59.323Z"`

### auditHistory 4

- **id:** agent_event_290f155a-135f-42b8-a9c0-5a1e8db6af1f
- **agent_id:** agent_50e31774-3453-4697-9c92-6c4289f4a44c
- **event_type:** resumed
- **actor_type:** owner
- **actor_id:** acceptance-sarah
- **summary:** Analyst resumed.
- **changes:** `{}`
- **created_at:** `"2026-09-20T19:58:59.791Z"`

### auditHistory 5

- **id:** agent_event_c6d70741-66fd-4306-9972-ab21137a9802
- **agent_id:** agent_553b0c31-1c69-4eb6-bb02-752473013119
- **event_type:** created
- **actor_type:** owner
- **actor_id:** acceptance-sarah
- **summary:** Analyst Copy Agent created.
- **changes:** `{   "capabilityIds": [] }`
- **created_at:** `"2026-09-20T19:58:59.889Z"`

### auditHistory 6

- **id:** agent_event_0f72826b-05c7-4ffc-af8c-09d55fa66770
- **agent_id:** agent_553b0c31-1c69-4eb6-bb02-752473013119
- **event_type:** duplicated
- **actor_type:** owner
- **actor_id:** acceptance-sarah
- **summary:** Analyst Copy duplicated from Analyst.
- **changes:** `{   "sourceAgentId": "agent_50e31774-3453-4697-9c92-6c4289f4a44c" }`
- **created_at:** `"2026-09-20T19:58:59.890Z"`

### auditHistory 7

- **id:** agent_event_e664e15c-8fcb-400e-8bb8-f94024dacb2a
- **agent_id:** agent_553b0c31-1c69-4eb6-bb02-752473013119
- **event_type:** archived
- **actor_type:** owner
- **actor_id:** acceptance-sarah
- **summary:** Analyst Copy archived.
- **changes:** `{}`
- **created_at:** `"2026-09-20T19:59:00.424Z"`

### auditHistory 8

- **id:** agent_event_f9ba4c9d-f7b8-4148-bc79-40234d3179bf
- **agent_id:** agent_edd02220-a18a-4106-ae13-98e9cdbba2a7
- **event_type:** created
- **actor_type:** owner
- **actor_id:** acceptance-sarah
- **summary:** Founder / Chief of Staff Agent created.
- **changes:** `{   "capabilityIds": [     "goals.operating-system",     "web.search",     "web.read",     "files.read",     "files.write"   ] }`
- **created_at:** `"2026-09-20T20:00:18.432Z"`

### auditHistory 9

- **id:** agent_event_e1caf786-974e-4955-bd19-8c2af4a4bbe3
- **agent_id:** agent_50e31774-3453-4697-9c92-6c4289f4a44c
- **event_type:** paused
- **actor_type:** owner
- **actor_id:** acceptance-sarah
- **summary:** Analyst paused.
- **changes:** `{}`
- **created_at:** `"2026-09-20T20:22:39.589Z"`

### auditHistory 10

- **id:** agent_event_fe9af07f-9f01-4ead-9754-4b9c1d7c122a
- **agent_id:** agent_50e31774-3453-4697-9c92-6c4289f4a44c
- **event_type:** resumed
- **actor_type:** owner
- **actor_id:** acceptance-sarah
- **summary:** Analyst resumed.
- **changes:** `{}`
- **created_at:** `"2026-09-20T20:22:39.613Z"`
