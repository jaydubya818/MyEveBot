# MyEve Backup

Created: 2026-09-20T19:53:34.302Z
Format: myeve-backup v1
Verified at creation: yes

This owner-neutral archive contains canonical MyEve records in machine-readable JSON and human-readable Markdown.
The JSON files are canonical for a future restore; the Markdown files are for inspection.

It does not contain passwords, API keys, OAuth tokens, webhook secrets, provider authorization identifiers, or internal storage keys.
Files marked referenced or external are metadata only and are not backed up as binary content.
Connected apps require owner reconnection. Restored schedules and webhooks must remain disabled until owner review.

Browser Profiles require provider reconnection and grant reconciliation. Computer, control, and Approval records are non-restorable history and never confer authority.

Use MyEve's Owner Data Center to verify checksums and compatibility before restore.
Restore mutation is not enabled in this release.
