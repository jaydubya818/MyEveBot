# Agents

Agent definitions, limits, assigned capabilities, and lifecycle history

Completeness: complete
Portability: fully restorable

## agents

### Ava

- **id:** agent_66a1e235-c274-4052-a0aa-db757e9b3e6b
- **name:** Ava
- **slug:** ava
- **label:** —
- **role:** Primary personal agent
- **description:** Helps the owner interpret goals, plan work, focus, and review progress.
- **instructions:** You are the owner's primary personal agent.
- **status:** active
- **is_primary:** true
- **preferred_model:** anthropic/claude-sonnet-5
- **reasoning_preference:** default
- **avatar_config:** `{}`
- **risk_ceiling:** high
- **notification_policy:** activity
- **max_steps:** 20
- **max_runtime_seconds:** 900
- **max_estimated_cost_usd:** 2.0000
- **max_retries:** 1
- **created_by_type:** system
- **created_by_id:** —
- **created_at:** `"2026-09-20T19:45:32.629Z"`
- **updated_at:** `"2026-09-20T19:45:32.629Z"`
- **archived_at:** —

## capabilities

No records.

## audit History

### auditHistory 1

- **id:** agent_event_1dded9b5-943e-477b-8adf-9a2f9f50d018
- **agent_id:** agent_66a1e235-c274-4052-a0aa-db757e9b3e6b
- **event_type:** created
- **actor_type:** system
- **actor_id:** —
- **summary:** Ava initialized as the primary Agent.
- **changes:** `{}`
- **created_at:** `"2026-09-20T19:45:32.635Z"`
