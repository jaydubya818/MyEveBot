# Knowledge

Knowledge records, sources, provenance, and relationships

Completeness: complete
Portability: fully restorable

## sources

No records.

## records

No records.

## provenance

No records.

## relationships

No records.
