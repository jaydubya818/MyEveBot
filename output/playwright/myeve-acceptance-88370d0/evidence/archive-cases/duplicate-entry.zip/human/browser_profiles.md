# Browser profiles

Persistent Browser Profile and Agent grant metadata without provider authentication state

Completeness: metadata only
Portability: restorable with reconnection

> Provider authentication state is excluded. A future restore must reconnect profiles and revalidate every Agent grant.

## profiles

No records.

## grants

No records.
