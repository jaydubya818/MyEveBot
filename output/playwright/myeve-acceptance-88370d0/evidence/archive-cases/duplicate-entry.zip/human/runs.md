# Runs & evidence

Delegated runs, checks, evidence metadata, and transitions

Completeness: complete
Portability: fully restorable

## runs

No records.

## agent Runs

### agentRuns 1

- **id:** agent_run_wrun_01M305NJZ82PD91CR926H4V7MV_turn_0
- **session_id:** wrun_01M305NJZ82PD91CR926H4V7MV
- **agent_id:** agent_66a1e235-c274-4052-a0aa-db757e9b3e6b
- **thread_id:** 1d977819-1d00-42c3-b607-5c229c579976
- **status:** failed
- **model_steps:** 0
- **estimated_cost_usd:** 0.0000
- **started_at:** `"2026-09-20T19:46:11.294Z"`
- **completed_at:** `"2026-09-20T19:46:11.340Z"`
- **updated_at:** `"2026-09-20T19:46:11.340Z"`
- **executor_kind:** primary-agent
- **role_id:** —

## specialists

No records.

## acceptance Checks

No records.

## milestones

No records.

## transitions

No records.

## context Entries

No records.

## context Assemblies

### contextAssemblies 1

- **id:** context_f7756d45-8ee1-470e-99b0-443f70f25157
- **agent_id:** agent_66a1e235-c274-4052-a0aa-db757e9b3e6b
- **session_id:** wrun_01M305NJZ82PD91CR926H4V7MV
- **agent_run_id:** agent_run_wrun_01M305NJZ82PD91CR926H4V7MV_turn_0
- **thread_id:** 1d977819-1d00-42c3-b607-5c229c579976
- **goal_id:** —
- **goal_task_id:** —
- **task_run_id:** —
- **memory_refs:** `[]`
- **thread_summary_id:** —
- **source_refs:** `[   "agent:agent_66a1e235-c274-4052-a0aa-db757e9b3e6b" ]`
- **estimated_tokens:** 4064
- **budget:** `{   "maximumTokens": 12000,   "retrievalTokens": 4000,   "reservedInstructionTokens": 4000 }`
- **created_at:** `"2026-09-20T19:46:11.301Z"`
