# Approval history

Exact-action approval bindings, risk, expected effects, status, expiry, and decisions

Completeness: complete
Portability: non restorable

> Approval bindings and decisions are audit history. A restore must never reactivate pending or approved execution authority.

## approvals

No records.
